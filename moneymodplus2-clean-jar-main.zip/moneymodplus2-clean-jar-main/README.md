# moneymodplus2-clean-jar

uh i just built the sources from https://github.com/PlutoSolutions/moneymodplus2-src/tree/main/src/main/java and here it is

i also removed discord rpc from the client don't ask me why
